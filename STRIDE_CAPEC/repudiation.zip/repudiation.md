# Repudiation

## [CAPEC-268: Audit Log Manipulation](https://capec.mitre.org/data/definitions/268.html)

### [CAPEC-93: Log Injection-Tampering-Forging](https://capec.mitre.org/data/definitions/93.html)

### [CAPEC-81: Web Logs Tampering](https://capec.mitre.org/data/definitions/81.html)

## [CAPEC-571: Block Logging to Central Repository](https://capec.mitre.org/data/definitions/571.html)

## [CAPEC-67: String Format Overflow in syslog()](https://capec.mitre.org/data/definitions/67.html)

## [CAPEC-195: Principal Spoof](https://capec.mitre.org/data/definitions/195.html)

### [CAPEC-587: Cross Frame Scripting (XFS)](https://capec.mitre.org/data/definitions/587.html)

### [CAPEC-599: Terrestrial Jamming](https://capec.mitre.org/data/definitions/599.html)

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

