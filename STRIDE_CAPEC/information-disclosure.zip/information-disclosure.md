# Information Disclosure

## [CAPEC-129: Pointer Manipulation](https://capec.mitre.org/data/definitions/129.html)

## [CAPEC-212: Functionality Misuse](https://capec.mitre.org/data/definitions/212.html)

### [CAPEC-48: Passing Local Filenames to Functions That Expect a URL](https://capec.mitre.org/data/definitions/48.html)

### [CAPEC-111: JSON Hijacking (aka JavaScript Hijacking)](https://capec.mitre.org/data/definitions/111.html)

### [CAPEC-620: Drop Encryption Level](https://capec.mitre.org/data/definitions/620.html)

- [CAPEC-606: Weakening of Cellular Encryption](https://capec.mitre.org/data/definitions/606.html)

## [CAPEC-216: Communication Channel Manipulation](https://capec.mitre.org/data/definitions/216.html)

### [CAPEC-12: Choosing Message Identifier](https://capec.mitre.org/data/definitions/12.html)

### [CAPEC-217: Exploiting Incorrectly Configured SSL](https://capec.mitre.org/data/definitions/217.html)

## [CAPEC-554: Functionality Bypass](https://capec.mitre.org/data/definitions/554.html)

### [CAPEC-179: Calling Micro-Services Directly](https://capec.mitre.org/data/definitions/179.html)

### [CAPEC-464: Evercookie](https://capec.mitre.org/data/definitions/464.html)

### [CAPEC-465: Transparent Proxy Abuse](https://capec.mitre.org/data/definitions/465.html)

## [CAPEC-117: Interception](https://capec.mitre.org/data/definitions/117.html)

### [CAPEC-157: Sniffing Attacks](https://capec.mitre.org/data/definitions/157.html)

- [CAPEC-57: Utilising REST's Trust in the System Resources to Obtain Sensitive Data](https://capec.mitre.org/data/definitions/57.html)

- [CAPEC-65: Sniff Application Code](https://capec.mitre.org/data/definitions/65.html)

- [CAPEC-158: Sniffing Network Traffic](https://capec.mitre.org/data/definitions/158.html)

- [CAPEC-609: Cellular Traffic Intercept](https://capec.mitre.org/data/definitions/609.html)

### [CAPEC-499: Android Intent Intercept](https://capec.mitre.org/data/definitions/499.html)

- [CAPEC-501: Android Activity Hijack](https://capec.mitre.org/data/definitions/501.html)

### [CAPEC-651: Eavesdropping](https://capec.mitre.org/data/definitions/651.html)

- [CAPEC-508: Shoulder Surfing](https://capec.mitre.org/data/definitions/508.html)

- [CAPEC-634: Probe Audio and Video Peripherals](https://capec.mitre.org/data/definitions/634.html)

## [CAPEC-116: Excavation](https://capec.mitre.org/data/definitions/116.html)

### [CAPEC-54: Query System for Information](https://capec.mitre.org/data/definitions/54.html)

- [CAPEC-127: Directory Indexing](https://capec.mitre.org/data/definitions/127.html)

- [CAPEC-95: WSDL Scanning](https://capec.mitre.org/data/definitions/95.html)

- [CAPEC-215: Fuzzing for Application Mapping](https://capec.mitre.org/data/definitions/215.html)

- [CAPEC-261: Fuzzing for Garnering Other Adjacent user/sensitive data](https://capec.mitre.org/data/definitions/261.html)

- [CAPEC-462: Cross-Domain Search Timing](https://capec.mitre.org/data/definitions/462.html)

### [CAPEC:150: Collect Data From Common Resource Locations](https://capec.mitre.org/data/definitions/150.html)

- [CAPEC-143: Detect Unpublicised Web Pages](https://capec.mitre.org/data/definitions/143.html)

- [CAPEC-144: Detect Unpublicised Web Services](https://capec.mitre.org/data/definitions/144.html)

- [CAPEC-155: Screen Temporary Files for Sensitive Information](https://capec.mitre.org/data/definitions/155.html)

- [CAPEC-406: Dumpster Diving](https://capec.mitre.org/data/definitions/406.html)

- [CAPEC-637: Collect Data from Clipboard](https://capec.mitre.org/data/definitions/637.html)

- [CAPEC-647: Collect Data from Registries](https://capec.mitre.org/data/definitions/647.html)

- [CAPEC-648: Collect Data from Screen Capture](https://capec.mitre.org/data/definitions/648.html)

### [CAPEC-545: Pull Data From System Resources](https://capec.mitre.org/data/definitions/545.html)

- [CAPEC-498: Probe iOS Screenshots](https://capec.mitre.org/data/definitions/498.html)

- [CAPEC-546: Incomplete Data Deletion in a Multi-Tenant Environment](https://capec.mitre.org/data/definitions/546.html)

- [CAPEC-634: Probe Audio and Video Peripherals](https://capec.mitre.org/data/definitions/634.html)

- [CAPEC-639: Probe System Files](https://capec.mitre.org/data/definitions/639.html)

### [CAPEC-569: Collect Data as Provided by Users](https://capec.mitre.org/data/definitions/569.html)

- [CAPEC-568: Capture Credentials via Keylogger](https://capec.mitre.org/data/definitions/568.html)

### [CAPEC-675: Retrieve Data from Decommissioned Devices](https://capec.mitre.org/data/definitions/675.html)

## [CAPEC-169: Footprinting](https://capec.mitre.org/data/definitions/169.html)

### [CAPEC-292: Host Discovery](https://capec.mitre.org/data/definitions/292.html)

- [CAPEC-285: ICMP Echo Request Ping](https://capec.mitre.org/data/definitions/285.html)

- [CAPEC-294: ICMP Address Mask Request](https://capec.mitre.org/data/definitions/294.html)

- [CAPEC-295: Timestamp Request](https://capec.mitre.org/data/definitions/295.html)

- [CAPEC-296: ICMP Information Request](https://capec.mitre.org/data/definitions/296.html)

- [CAPEC-297: TCP ACK Ping](https://capec.mitre.org/data/definitions/297.html)

- [CAPEC-298: UDP Ping](https://capec.mitre.org/data/definitions/298.html)

- [CAPEC-299: TCP SYN Ping](https://capec.mitre.org/data/definitions/299.html)

- [CAPEC-612: WiFi MAC Address Tracking](https://capec.mitre.org/data/definitions/612.html)

- [CAPEC-613: WiFi SSID Tracking](https://capec.mitre.org/data/definitions/613.html)

- [CAPEC-618: Cellular Broadcast Message Request](https://capec.mitre.org/data/definitions/618.html)

- [CAPEC-619: Signal Strength Tracking](https://capec.mitre.org/data/definitions/619.html)

### [CAPEC-300: Port Scanning](https://capec.mitre.org/data/definitions/300.html)

- [CAPEC-287: TCP SYN Scan](https://capec.mitre.org/data/definitions/287.html)

- [CAPEC-301: TCP Connect Scan](https://capec.mitre.org/data/definitions/301.html)

- [CAPEC-302: TCP FIN Scan](https://capec.mitre.org/data/definitions/302.html)

- [CAPEC-303: TCP Xmas Scan](https://capec.mitre.org/data/definitions/303.html)

- [CAPEC-304: TCP Null Scan](https://capec.mitre.org/data/definitions/304.html)

- [CAPEC-305: TCP ACK Scan](https://capec.mitre.org/data/definitions/305.html)

- [CAPEC-306: TCP Window Scan](https://capec.mitre.org/data/definitions/306.html)

- [CAPEC-307: TCP RPC Scan](https://capec.mitre.org/data/definitions/307.html)

- [CAPEC-308: UDP Scan](https://capec.mitre.org/data/definitions/308.html)

### [CAPEC-309: Network Topology Mapping](https://capec.mitre.org/data/definitions/309.html)

- [CAPEC-290: Enumerate Mail Exchange Records](https://capec.mitre.org/data/definitions/290.html)

- [CAPEC-291: DNS Zone Transfers](https://capec.mitre.org/data/definitions/291.html)

- [CAPEC-293: Traceroute Route Enumeration](https://capec.mitre.org/data/definitions/293.html)

- [CAPEC-643: Identify Shared Files/Directories on System](https://capec.mitre.org/data/definitions/643.html)

### [CAPEC-497: File Discovery](https://capec.mitre.org/data/definitions/497.html)

- [CAPEC-149: Explore for Predictable Temporary File Names](https://capec.mitre.org/data/definitions/149.html)

### [CAPEC-529: Malware-Directed Internal Reconnaissance](https://capec.mitre.org/data/definitions/529.html)

### [CAPEC-573: Process Footprinting](https://capec.mitre.org/data/definitions/573.html)

### [CAPEC-574: Services Footprinting](https://capec.mitre.org/data/definitions/574.html)

### [CAPEC-575: Account Footprinting](https://capec.mitre.org/data/definitions/575.html)

### [CAPEC-576: Group Permission Footprinting](https://capec.mitre.org/data/definitions/576.html)

### [CAPEC-577: Owner Footprinting](https://capec.mitre.org/data/definitions/577.html)

### [CAPEC-580: System Footprinting](https://capec.mitre.org/data/definitions/580.html)

- [CAPEC-85: AJAX Footprinting](https://capec.mitre.org/data/definitions/85.html)

- [CAPEC-581: Security Software Footprinting](https://capec.mitre.org/data/definitions/581.html)

### [CAPEC-646: Peripheral Footprinting](https://capec.mitre.org/data/definitions/646.html)

## [CAPEC-224: Fingerprinting](https://capec.mitre.org/data/definitions/224.html)

### [CAPEC-312: Active OS Fingerprinting](https://capec.mitre.org/data/definitions/312.html)

- [CAPEC-317: IP ID Sequencing Probe](https://capec.mitre.org/data/definitions/317.html)

- [CAPEC-318: IP 'ID' Echoed Byte-Order Probe](https://capec.mitre.org/data/definitions/318.html)

- [CAPEC-319: IP (DF) 'Don't Fragment Bit' Echoing Probe](https://capec.mitre.org/data/definitions/319.html)

- [CAPEC-320: TCP Timestamp Probe](https://capec.mitre.org/data/definitions/320.html)

- [CAPEC-321: 	TCP Sequence Number Probe](https://capec.mitre.org/data/definitions/321.html)

- [CAPEC-322: TCP (ISN) Greatest Common Divisor Probe](https://capec.mitre.org/data/definitions/322.html)

- [CAPEC-323: 	TCP (ISN) Counter Rate Probe](https://capec.mitre.org/data/definitions/323.html)

- [CAPEC-324: TCP (ISN) Sequence Predictability Probe](https://capec.mitre.org/data/definitions/324.html)

- [CAPEC-325: TCP Congestion Control Flag (ECN) Probe](https://capec.mitre.org/data/definitions/325.html)

- [CAPEC-326: TCP Initial Window Size Probe](https://capec.mitre.org/data/definitions/326.html)

- [CAPEC-327: 	TCP Options Probe](https://capec.mitre.org/data/definitions/327.html)

- [CAPEC-328: TCP 'RST' Flag Checksum Probe](https://capec.mitre.org/data/definitions/328.html)

- [CAPEC-329: ICMP Error Message Quoting Probe](https://capec.mitre.org/data/definitions/329.html)

- [CAPEC-330: ICMP Error Message Echoing Integrity Probe](https://capec.mitre.org/data/definitions/330.html)

- [CAPEC-331: 	ICMP IP Total Length Field Probe](https://capec.mitre.org/data/definitions/331.html)

- [CAPEC-332: 	ICMP IP 'ID' Field Error Message Probe](https://capec.mitre.org/data/definitions/332.html)

### [CAPEC-313: Passive OS Fingerprinting](https://capec.mitre.org/data/definitions/313.html)

### [CAPEC-541: Application Fingerprinting](https://capec.mitre.org/data/definitions/541.html)

- [CAPEC-170: Web Application Fingerprinting](https://capec.mitre.org/data/definitions/170.html)

- [CAPEC-310: Scanning for Vulnerable Software](https://capec.mitre.org/data/definitions/310.html)

- [CAPEC-472: Browser Fingerprinting](https://capec.mitre.org/data/definitions/472.html)

## [CAPEC-11: Cause Web Server Misclassification](https://capec.mitre.org/data/definitions/11.html)

## [CAPEC-192: Protocol Analysis](https://capec.mitre.org/data/definitions/192.html)

### [CAPEC-97: Cryptanalysis](https://capec.mitre.org/data/definitions/97.html)

- [CAPEC-463: Padding Oracle Crypto Attack](https://capec.mitre.org/data/definitions/463.html)

- [CAPEC-608: Cryptanalysis of Cellular Encryption](https://capec.mitre.org/data/definitions/608.html)

## [CAPEC-188: Reverse Engineering](https://capec.mitre.org/data/definitions/188.html)

### [CAPEC-167: White Box Reverse Engineering](https://capec.mitre.org/data/definitions/167.html)

- [CAPEC-37: Retrieve Embedded Sensitive Information](https://capec.mitre.org/data/definitions/37.html)

- [CAPEC-190: Reverse Engineer an Executable to Expose Assumed Hidden Functionality](https://capec.mitre.org/data/definitions/190.html)

- [CAPEC-191: Read Sensitive Constants Within an Executable](https://capec.mitre.org/data/definitions/191.html)

- [CAPEC-204: Lifting Sensitive Data Embedded in Cache](https://capec.mitre.org/data/definitions/204.html)

### [CAPEC-189: Black Box Reverse Engineering](https://capec.mitre.org/data/definitions/189.html)

- [CAPEC-621: Analysis of Packet Timing and Sizes](https://capec.mitre.org/data/definitions/621.html)

- [CAPEC-622: Electromagnetic Side-Channel Attack](https://capec.mitre.org/data/definitions/622.html)

- [CAPEC-623: Compromising Emanations Attack](https://capec.mitre.org/data/definitions/623.html)

## [CAPEC-410: Information Elicitation](https://capec.mitre.org/data/definitions/410.html)

### [CAPEC-407: Pretexting](https://capec.mitre.org/data/definitions/407.html)

- [CAPEC-383: Harvesting Information via API Event Monitoring](https://capec.mitre.org/data/definitions/383.html)

- [CAPEC-412: Pretexting via Customer Service](https://capec.mitre.org/data/definitions/412.html)

- [CAPEC-413: Pretexting via Tech Support](https://capec.mitre.org/data/definitions/413.html)

- [CAPEC-414: Pretexting via Delivery Person](https://capec.mitre.org/data/definitions/414.html)

- [CAPEC-415: Pretexting via Phone](https://capec.mitre.org/data/definitions/415.html)

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

