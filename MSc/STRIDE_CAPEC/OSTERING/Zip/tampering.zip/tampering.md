# Tampering

## [CAPEC-123: Buffer Manipulation](https://capec.mitre.org/data/definitions/123.html)

### [CAPEC-100: Overflow Buffers](https://capec.mitre.org/data/definitions/100.html)

- [CAPEC-10: Buffer Overflow via Environment Variables](https://capec.mitre.org/data/definitions/10.html)

- [CAPEC-14: Client-side Injection-induced Buffer Overflow](https://capec.mitre.org/data/definitions/14.html)

- [CAPEC-24: Filter Failure through Buffer Overflow](https://capec.mitre.org/data/definitions/24.html)

- [CAPEC-256: SOAP Array Overflow](https://capec.mitre.org/data/definitions/256.html)

- [CAPEC-42: MIME Conversion](https://capec.mitre.org/data/definitions/42.html)

- [CAPEC-44: Overflow Binary Resource File](https://capec.mitre.org/data/definitions/44.html)

- [CAPEC-45: Buffer Overflow via Symbolic Links](https://capec.mitre.org/data/definitions/45.html)

- [CAPEC-46: Overflow Variables and Tags](https://capec.mitre.org/data/definitions/46.html)

- [CAPEC-47: Buffer Overflow via Parameter Expansion](https://capec.mitre.org/data/definitions/47.html)

- [CAPEC-67: String Format Overflow in syslog()](https://capec.mitre.org/data/definitions/67.html)

- [CAPEC-8: Buffer Overflow in an API Call](https://capec.mitre.org/data/definitions/8.html)

- [CAPEC-9: Buffer Overflow in Local Command-Line Utilities](https://capec.mitre.org/data/definitions/9.html)

### [CAPEC-540: Overread Buffers](https://capec.mitre.org/data/definitions/540.html)

## [CAPEC-124: Shared Resource Manipulation](https://capec.mitre.org/data/definitions/124.html)

### [CAPEC-26: Leveraging Race Conditions](https://capec.mitre.org/data/definitions/26.html)

### [CAPEC-27: Leveraging Race Conditions via Symbolic Links](https://capec.mitre.org/data/definitions/27.html)

### [CAPEC-29: Leveraging Time-of-Check and Time-of-Use (TOCTOU) Race Conditions](https://capec.mitre.org/data/definitions/29.html)

## [CAPEC-129: Pointer Manipulation](https://capec.mitre.org/data/definitions/129.html)

## [CAPEC-272: Protocol Manipulation](https://capec.mitre.org/data/definitions/272.html)

### [CAPEC-90: Reflection Attack in Authentication Protocol](https://capec.mitre.org/data/definitions/90.html)

### [CAPEC-220: Client-Server Protocol Manipulation](https://capec.mitre.org/data/definitions/220.html)

- [CAPEC-5: Blue Boxing](https://capec.mitre.org/data/definitions/5.html)

- [CAPEC-33: HTTP Request Smuggling](https://capec.mitre.org/data/definitions/33.html)

- [CAPEC-34: HTTP Response Splitting](https://capec.mitre.org/data/definitions/34.html)

- [CAPEC-105: HTTP Request Splitting](https://capec.mitre.org/data/definitions/105.html)

- [CAPEC-273: HTTP Response Smuggling](https://capec.mitre.org/data/definitions/273.html)

- [CAPEC-274: HTTP Verb Tampering](https://capec.mitre.org/data/definitions/274.html)

### [CAPEC-276: Inter-Component Protocol Manipulation](https://capec.mitre.org/data/definitions/276.html)

- [CAPEC-665: Exploitation of Thunderbolt Protection Flaws](https://capec.mitre.org/data/definitions/665.html)

### [CAPEC-277: Data Interchange Protocol Manipulation](https://capec.mitre.org/data/definitions/277.html)

### [CAPEC-278: Web Services Protocol Manipulation](https://capec.mitre.org/data/definitions/278.html)

- [CAPEC-201: Serialized Data External Linking](https://capec.mitre.org/data/definitions/201.html)

- [CAPEC-221: Data Serialization External Entities Blowup](https://capec.mitre.org/data/definitions/221.html)

- [CAPEC-279: SOAP Manipulation](https://capec.mitre.org/data/definitions/279.html)

## [CAPEC-153: Input Data Manipulation](https://capec.mitre.org/data/definitions/153.html)

### [CAPEC-126: Path Traversal](https://capec.mitre.org/data/definitions/126.html)

- [CAPEC-139: Relative Path Traversal](https://capec.mitre.org/data/definitions/139.html)

- [CAPEC-597: Absolute Path Traversal](https://capec.mitre.org/data/definitions/597.html)

- [CAPEC-76: Manipulating Web Input to File System Calls](https://capec.mitre.org/data/definitions/76.html)

### [CAPEC-128: Integer Attacks](https://capec.mitre.org/data/definitions/128.html)

- [CAPEC-92: Forced Integer Overflow](https://capec.mitre.org/data/definitions/92.html)

### [CAPEC-267: Leverage Alternate Encoding](https://capec.mitre.org/data/definitions/267.html)

- [CAPEC-120: Double Encoding](https://capec.mitre.org/data/definitions/120.html)

- [CAPEC-3: Using Leading 'Ghost' Character Sequences to Bypass Input Filters](https://capec.mitre.org/data/definitions/3.html)

- [CAPEC-4: Using Alternative IP Address Encodings](https://capec.mitre.org/data/definitions/4.html)

- [CAPEC-43: Exploiting Multiple Input Interpretation Layers](https://capec.mitre.org/data/definitions/43.html)

- [CAPEC-52: Embedding NULL Bytes](https://capec.mitre.org/data/definitions/52.html)

- [CAPEC-53: Postfix, Null Terminate, and Backslash](https://capec.mitre.org/data/definitions/53.html)

- [CAPEC-64: Using Slashes and URL Encoding Combined to Bypass Validation Logic](https://capec.mitre.org/data/definitions/64.html)

- [CAPEC-71: Using Unicode Encoding to Bypass Validation Logic](https://capec.mitre.org/data/definitions/71.html)

- [CAPEC-72: URL Encoding](https://capec.mitre.org/data/definitions/72.html)

- [CAPEC-78: Using Escaped Slashes in Alternate Encoding](https://capec.mitre.org/data/definitions/78.html)

- [CAPEC-79: Using Slashes in Alternate Encoding](https://capec.mitre.org/data/definitions/79.html)

- [CAPEC-80: Using UTF-8 Encoding to Bypass Validation Logic](https://capec.mitre.org/data/definitions/80.html)

### [CAPEC-28: Fuzzing](https://capec.mitre.org/data/definitions/28.html)

### [CAPEC-33: HTTP Request Smuggling](https://capec.mitre.org/data/definitions/33.html)

### [CAPEC-34: HTTP Response Splitting](https://capec.mitre.org/data/definitions/34.html)

### [CAPEC-105: HTTP Request Splitting](https://capec.mitre.org/data/definitions/105.html)

### [CAPEC-165: File Manipulation](https://capec.mitre.org/data/definitions/165.html)

- [CAPEC-73: User Controlled Filename](https://capec.mitre.org/data/definitions/73.html)

- [CAPEC-572: Artificially Inflate File Sizes](https://capec.mitre.org/data/definitions/572.html)

	- [CAPEC-655: Avoid Security Tool Identification by Adding Data](https://capec.mitre.org/data/definitions/655.html)

- [CAPEC-635: Alternative Execution Due to Deceptive Filenames](https://capec.mitre.org/data/definitions/635.html)

	- [CAPEC-649: Adding a Space to a File Extension](https://capec.mitre.org/data/definitions/649.html)

- [CAPEC-636: Hiding Malicious Data or Code within Files](https://capec.mitre.org/data/definitions/636.html)

	- [CAPEC-168: Windows ::DATA Alternate Data Stream](https://capec.mitre.org/data/definitions/168.html)

### [CAPEC-74: Manipulating State](https://capec.mitre.org/data/definitions/74.html)

- [CAPEC-140: Bypassing of Intermediate Forms in Multiple-Form Sets](https://capec.mitre.org/data/definitions/140.html)

- [CAPEC-663: Exploitation of TransientInstruction Execution](https://capec.mitre.org/data/definitions/663.html)

### [CAPEC-75: Manipulating Writeable Configuration Files](https://capec.mitre.org/data/definitions/75.html)

### [CAPEC-113: Interface Manipulation](https://capec.mitre.org/data/definitions/113.html)

- [CAPEC-133: Try All Common Switches](https://capec.mitre.org/data/definitions/133.html)

- [CAPEC-160: Exploit Script-Based APIs](https://capec.mitre.org/data/definitions/160.html)

### [CAPEC-176: Configuration/Environment Manipulation](https://capec.mitre.org/data/definitions/176.html)

- [CAPEC-75: Manipulating Writeable Configuration Files](https://capec.mitre.org/data/definitions/75.html)

- [CAPEC-203: Manipulate Registry Information](https://capec.mitre.org/data/definitions/203.html)

	- [CAPEC-51: Poison Web Service Registry](https://capec.mitre.org/data/definitions/51.html)

	- [CAPEC-270: Modification of Registry Run Keys](https://capec.mitre.org/data/definitions/270.html)

	- [CAPEC-478: Modification of Windows Service Configuration](https://capec.mitre.org/data/definitions/478.html)

- [CAPEC-271: Schema Poisoning](https://capec.mitre.org/data/definitions/271.html)

	- [CAPEC-146: XML Schema Poisoning](https://capec.mitre.org/data/definitions/146.html)

- [CAPEC-536: Data Injection During Configuration](https://capec.mitre.org/data/definitions/536.html)

- [CAPEC-578: Disable Security Software](https://capec.mitre.org/data/definitions/578.html)

## [CAPEC-161: Infrastructure Manipulation](https://capec.mitre.org/data/definitions/161.html)

### [CAPEC-481: Contradictory Destinations inTraffic Routing Schemes](https://capec.mitre.org/data/definitions/481.html)

### [CAPEC-166: Force the System to Reset Values](https://capec.mitre.org/data/definitions/166.html)

### [CAPEC-141: Cache Poisoning](https://capec.mitre.org/data/definitions/141.html)

- [CAPEC-51: Poison Web Service Registry](https://capec.mitre.org/data/definitions/51.html)

- [CAPEC-142: DNS Cache Poisoning](https://capec.mitre.org/data/definitions/142.html)

### [CAPEC-268: Audit Log Manipulation](https://capec.mitre.org/data/definitions/268.html)

- [CAPEC-93: Log Injection-Tampering-Forging](https://capec.mitre.org/data/definitions/93.html)

- [CAPEC-81: Web Logs Tampering](https://capec.mitre.org/data/definitions/81.html)

### [CAPEC-571: Block Logging to Central Repository](https://capec.mitre.org/data/definitions/571.html)

## [CAPEC-184: Software Integrity Attack](https://capec.mitre.org/data/definitions/184.html)

### [CAPEC-185: Malicious Software Download](https://capec.mitre.org/data/definitions/185.html)

### [CAPEC-186: Malicious Software Update](https://capec.mitre.org/data/definitions/186.html)

- [CAPEC-187: Malicious Automated Software Update via Redirection](https://capec.mitre.org/data/definitions/187.html)

- [CAPEC-533: Malicious Manual Software Update](https://capec.mitre.org/data/definitions/553.html)

- [CAPEC-614: Rooting SIM Cards ](https://capec.mitre.org/data/definitions/614.html)

- [CAPEC-657: Malicious Automated Software Update via Spoofing](https://capec.mitre.org/data/definitions/657.html)

### [CAPEC-663: Exploitation of Transient Instruction Execution](https://capec.mitre.org/data/definitions/663.html)

### [CAPEC-669: Alteration of a Software Update](https://capec.mitre.org/data/definitions/669.html)

## [CAPEC-438: Modification During Manufacture](https://capec.mitre.org/data/definitions/438.html)

### [CAPEC-444: Development Alteration](https://capec.mitre.org/data/definitions/444.html)

- [CAPEC-206: Signing Malicious Code](https://capec.mitre.org/data/definitions/206.html)

- [CAPEC-443: Malicious Logic Inserted into Product Software by Authorized Developer](https://capec.mitre.org/data/definitions/443.html)

- [CAPEC-445: Malicious Logic Insertion into Product Software via Configuration Management Manipulation](https://capec.mitre.org/data/definitions/445.html)

- [CAPEC-446: Malicious Logic Insertion into Product Software via 3rd Party Component Dependency](https://capec.mitre.org/data/definitions/446.html)

- [CAPEC-511: Infiltration of Software Development Environment](https://capec.mitre.org/data/definitions/511.html)

- [CAPEC-516: Hardware Component Substitution During Baselining ](https://capec.mitre.org/data/definitions/516.html)

- [CAPEC-520: Counterfeit Hardware Component Inserted During Product Assembly](https://capec.mitre.org/data/definitions/520.html)

- [CAPEC-532: Altered Installed BIOS](https://capec.mitre.org/data/definitions/532.html)

- [CAPEC-537: Infiltration of Hardware Development Environment](https://capec.mitre.org/data/definitions/537.html)

- [CAPEC-538: Open-Source Library Manipulation](https://capec.mitre.org/data/definitions/538.html)

- [CAPEC-539: ASIC with Malicious Functionality](https://capec.mitre.org/data/definitions/539.html)

- [CAPEC-670: Software Development Tools Maliciously Altered](https://capec.mitre.org/data/definitions/670.html)

- [CAPEC-672: Malicious Code Implanted During Chip Programming](https://capec.mitre.org/data/definitions/672.html)

- [CAPEC-673: Developer Signing Maliciously Altered Software](https://capec.mitre.org/data/definitions/673.html)

- [CAPEC-678: System Build Data Maliciously Altered](https://capec.mitre.org/data/definitions/678.html)

### [CAPEC-447: Design Alteration](https://capec.mitre.org/data/definitions/447.html)

- [CAPEC-517: Documentation Alteration to Circumvent Dial-down](https://capec.mitre.org/data/definitions/517.html)

- [CAPEC-518: Documentation Alteration to Produce Under-Performing Systems](https://capec.mitre.org/data/definitions/518.html)

- [CAPEC-519: Documentation Alteration to Cause Errors in System Design](https://capec.mitre.org/data/definitions/519.html)

- [CAPEC-521: Hardware Design Specifications are Altered](https://capec.mitre.org/data/definitions/512.html)

- [CAPEC-671: Requirements for ASIC Functionality Maliciously Altered](https://capec.mitre.org/data/definitions/671.html)

- [CAPEC-674: Design for FPGA Maliciously Altered](https://capec.mitre.org/data/definitions/674.html)

## [CAPEC-440: Hardware Integrity Attack](https://capec.mitre.org/data/definitions/440.html)

### [CAPEC-401: Physically Hacking Hardware](https://capec.mitre.org/data/definitions/401.html)

- [CAPEC-402: Bypassing ATA Password Security](https://capec.mitre.org/data/definitions/402.html)

### [CAPEC-534: Malicious Hardware Update](https://capec.mitre.org/data/definitions/534.html)

- [CAPEC-531: Hardware Component Substitution](https://capec.mitre.org/data/definitions/531.html)

	- [CAPEC-530: Provide Counterfeit Component](https://capec.mitre.org/data/definitions/530.html)

	- [CAPEC-535: Malicious Gray Market Hardware](https://capec.mitre.org/data/definitions/535.html)

- [CAPEC-677: Server Functionality Compromise](https://capec.mitre.org/data/definitions/677.html)

## [CAPEC-439: Manipulation During Distribution](https://capec.mitre.org/data/definitions/439.html)

### [CAPEC-522: Malicious Hardware Component Replacement](https://capec.mitre.org/data/definitions/522.html)

### [CAPEC-523: Malicious Software Implanted](https://capec.mitre.org/data/definitions/523.html)

### [CAPEC-524: Rogue Integration Procedures](https://capec.mitre.org/data/definitions/524.html)

## [CAPEC-441: Malicious Logic Insertion](https://capec.mitre.org/data/definitions/441.html)

### [CAPEC-442: Infected Software](https://capec.mitre.org/data/definitions/442.html)

- [CAPEC-448: Embed Virus into DLL](https://capec.mitre.org/data/definitions/448.html)

### [CAPEC-452: Infected Hardware](https://capec.mitre.org/data/definitions/452.html)

- [CAPEC-638: Altered Component Firmware](https://capec.mitre.org/data/definitions/638.html)

### [CAPEC-456: Infected Memory](https://capec.mitre.org/data/definitions/456.html)

- [CAPEC-457: USB Memory Attacks](https://capec.mitre.org/data/definitions/457.html)

- [CAPEC-458: Flash Memory Attacks](https://capec.mitre.org/data/definitions/458.html)

## [CAPEC-548: Contaminate Resources](https://capec.mitre.org/data/definitions/548.html)

## [CAPEC-594: Traffic Injection](https://capec.mitre.org/data/definitions/594.html)

### [CAPEC-595: Connection Reset](https://capec.mitre.org/data/definitions/595.html)

- [CAPEC-596: TCP RST Injection](https://capec.mitre.org/data/definitions/596.html)

## [CAPEC-624: Hardware Fault Injection](https://capec.mitre.org/data/definitions/624.html)

### [CAPEC-625: Mobile Device Fault Injection](https://capec.mitre.org/data/definitions/625.html)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. 

Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

