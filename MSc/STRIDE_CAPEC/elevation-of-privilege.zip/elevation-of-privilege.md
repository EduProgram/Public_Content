# Elevation of Privilege

## [CAPEC-5: Blue Boxing](https://capec.mitre.org/data/definitions/5.html)

## [CAPEC-21: Exploitation of Trusted Identifiers](https://capec.mitre.org/data/definitions/21.html)

### [CAPEC-196: Session Credential Falsification through Forging](https://capec.mitre.org/data/definitions/196.html)

- [CAPEC-226: Session Credential Falsification through Manipulation](https://capec.mitre.org/data/definitions/226.html)

- [CAPEC-59: Session Credential Falsification through Prediction](https://capec.mitre.org/data/definitions/59.html)

### [CAPEC-510: SaaS User Request Forgery](https://capec.mitre.org/data/definitions/510.html)

### [CAPEC-593: Session Hijacking](https://capec.mitre.org/data/definitions/593.html)

- [CAPEC-102: Session Sidejacking](https://capec.mitre.org/data/definitions/102.html)

- [CAPEC-107: Cross Site Tracing](https://capec.mitre.org/data/definitions/107.html)

- [CAPEC-60: Reusing Session IDs (aka Session Replay)](https://capec.mitre.org/data/definitions/60.html)

- [CAPEC-61: Session Fixation](https://capec.mitre.org/data/definitions/61.html)

### [CAPEC-62: Cross Site Request Forgery](https://capec.mitre.org/data/definitions/62.html)

- [CAPEC-467: Cross Site Identification](https://capec.mitre.org/data/definitions/467.html)

## [CAPEC-114: Authentication Abuse](https://capec.mitre.org/data/definitions/114.html)

### [CAPEC-629: Unauthorized Use of Device Resources](https://capec.mitre.org/data/definitions/629.html)

### [CAPEC-90: Reflection Attack in Authentication Protocol](https://capec.mitre.org/data/definitions/90.html)

## [CAPEC-115: Authentication Bypass](https://capec.mitre.org/data/definitions/115.html)

### [CAPEC-461: Web Services API Signature Forgery Leveraging Hash Function Extension Weakness](https://capec.mitre.org/data/definitions/461.html)

### [CAPEC-480: Escaping Virtualization](https://capec.mitre.org/data/definitions/480.html)

- [CAPEC-237: Escaping a Sandbox by Calling Code in Another Language](https://capec.mitre.org/data/definitions/237.html)

### [CAPEC-664: Server Side Request Forgery](https://capec.mitre.org/data/definitions/664.html)

### [CAPEC-668: Key Negotiation of Bluetooth Attack (KNOB)](https://capec.mitre.org/data/definitions/668.html)

### [CAPEC-87: Forceful Browsing](https://capec.mitre.org/data/definitions/87.html)

## [CAPEC-22: Exploiting Trust in Client](https://capec.mitre.org/data/definitions/22.html)

### [CAPEC-202: Create Malicious Client](https://capec.mitre.org/data/definitions/202.html)

### [CAPEC-207: Removing Important Client Functionality](https://capec.mitre.org/data/definitions/207.html)

- [CAPEC-200: Removal of filters: Input filters, output filters, data masking](https://capec.mitre.org/data/definitions/200.html)

- [CAPEC-208: Removing/short-circuiting 'Purse' logic: removing/mutating 'cash' decrements](https://capec.mitre.org/data/definitions/208.html)

### [CAPEC-39: Manipulating Opaque Client-based Data Tokens](https://capec.mitre.org/data/definitions/39.html)

- [CAPEC-31: Accessing/Intercepting/Modifying HTTP Cookies](https://capec.mitre.org/data/definitions/31.html)

### [CAPEC-77: Manipulating User-Controlled Variables](https://capec.mitre.org/data/definitions/77.html)

- [CAPEC-13: Subverting Environment Variable Values](https://capec.mitre.org/data/definitions/13.html)

- [CAPEC-162: Manipulating Hidden Fields](https://capec.mitre.org/data/definitions/162.html)

## [CAPEC-94: Adversary in the Middle (AiTM)](https://capec.mitre.org/data/definitions/94.html)

### [CAPEC-219: XML Routing Detour Attacks](https://capec.mitre.org/data/definitions/219.html)

### [CAPEC-384: Application API Message Manipulation via Man-in-the-Middle](https://capec.mitre.org/data/definitions/384.html)

- [CAPEC-385: Transaction or Event Tampering via Application API Manipulation](https://capec.mitre.org/data/definitions/385.html)

- [CAPEC-389: Content Spoofing Via Application API Manipulation](https://capec.mitre.org/data/definitions/389.html)

### [CAPEC-386: Application API Navigation Remapping](https://capec.mitre.org/data/definitions/386.html)

- [CAPEC-387: Navigation Remapping To Propagate Malicious Content](https://capec.mitre.org/data/definitions/387.html)

- [CAPEC-388: Application API Button Hijacking](https://capec.mitre.org/data/definitions/388.html)

### [CAPEC-466: Leveraging Active Adversary in the Middle Attacks to Bypass Same Origin Policy](https://capec.mitre.org/data/definitions/466.html)

### [CAPEC-662: Adversary in the Browser (AiTB)](https://capec.mitre.org/data/definitions/662.html)

## [CAPEC-122: Privilege Abuse](https://capec.mitre.org/data/definitions/122.html)

### [CAPEC-1: Accessing Functionality Not Properly Constrained by ACLs](https://capec.mitre.org/data/definitions/1.html)

- [CAPEC-58: Restful Privilege Elevation](https://capec.mitre.org/data/definitions/58.html)

- [CAPEC-679: Exploitation of Improperly Configured or Implemented Memory Protections](https://capec.mitre.org/data/definitions/679.html)

- [CAPEC-680: Exploitation of Improperly Controlled Registers](https://capec.mitre.org/data/definitions/680.html)

- [CAPEC-681: Exploitation of Improperly Controlled Hardware Security Identifiers](https://capec.mitre.org/data/definitions/681.html)

- [CAPEC-36: Using Unpublished Interfaces](https://capec.mitre.org/data/definitions/36.html)

- [CAPEC-121: Exploit Non-Production Interfaces](https://capec.mitre.org/data/definitions/121.html)

	- [CAPEC-661: Root/Jailbreak Detection Evasion via Debugging](https://capec.mitre.org/data/definitions/661.html)

### [CAPEC-17: Using Malicious Files](https://capec.mitre.org/data/definitions/17.html)

- [CAPEC-177: Create files with the same name as files protected with a higher classification](https://capec.mitre.org/data/definitions/177.html)

- [CAPEC-263: Force Use of Corrupted Files](https://capec.mitre.org/data/definitions/263.html)

- [CAPEC-562: Modify Shared File](https://capec.mitre.org/data/definitions/562.html)

- [CAPEC-563: Add Malicious File to Shared Webroot](https://capec.mitre.org/data/definitions/563.html)

- [CAPEC-642: Replace Binaries](https://capec.mitre.org/data/definitions/642.html)

- [CAPEC-650: Upload a Web Shell to a Web Server](https://capec.mitre.org/data/definitions/650.html)

- [CAPEC-35: Leveraging Executable Code in Non-Executable Files](https://capec.mitre.org/data/definitions/35.html)

### [CAPEC-180: Exploiting Incorrectly Configured Access Control Security Levels](https://capec.mitre.org/data/definitions/180.html)

### [CAPEC-221: Data Serialization External Entities Blowup](https://capec.mitre.org/data/definitions/221.html)

### [CAPEC-503: WebView Exposure](https://capec.mitre.org/data/definitions/503.html)

## [CAPEC-233: Privilege Escalation](https://capec.mitre.org/data/definitions/233.html)

### [CAPEC-104: Cross Zone Scripting](https://capec.mitre.org/data/definitions/104.html)

### [CAPEC-234: Hijacking a privileged process](https://capec.mitre.org/data/definitions/234.html)

### [CAPEC-30: Hijacking a Privileged Thread of Execution](https://capec.mitre.org/data/definitions/30.html)

### [CAPEC-68: Subvert Code-signing Facilities](https://capec.mitre.org/data/definitions/68.html)

### [CAPEC-69: Target Programs with Elevated Privileges](https://capec.mitre.org/data/definitions/69.html)

## [CAPEC-390: Bypassing Physical Security](https://capec.mitre.org/data/definitions/390.html)

### [CAPEC-391: Bypassing Physical Locks](https://capec.mitre.org/data/definitions/391.html)

- [CAPEC-392: Lock Bumping](https://capec.mitre.org/data/definitions/392.html)

- [CAPEC-393: Lock Picking](https://capec.mitre.org/data/definitions/393.html)

- [CAPEC-394: Using a Snap Gun Lock to Force a Lock](https://capec.mitre.org/data/definitions/394.html)

### [CAPEC-395: Bypassing Electronic Locks and Access Controls](https://capec.mitre.org/data/definitions/395.html)

- [CAPEC-397: Cloning Magnetic Strip Cards](https://capec.mitre.org/data/definitions/397.html)

- [CAPEC-398: Magnetic Strip Card Brute Force Attacks](https://capec.mitre.org/data/definitions/398.html)

- [CAPEC-399: Cloning RFID Cards or Chips](https://capec.mitre.org/data/definitions/399.html)

- [CAPEC-400: RFID Chip Deactivation or Destruction](https://capec.mitre.org/data/definitions/400.html)

- [CAPEC-626: Smudge Attack](https://capec.mitre.org/data/definitions/626.html)

## [CAPEC-507: Physical Theft](https://capec.mitre.org/data/definitions/507.html)

## [CAPEC-560: Use of Known Domain Credentials](https://capec.mitre.org/data/definitions/560.html)

### [CAPEC-555: Remote Services with Stolen Credentials](https://capec.mitre.org/data/definitions/555.html)

### [CAPEC-600: Credential Stuffing](https://capec.mitre.org/data/definitions/600.html)

### [CAPEC-652: Use of Known Kerberos Credentials](https://capec.mitre.org/data/definitions/652.html)

- [CAPEC-509: Kerberoasting](https://capec.mitre.org/data/definitions/509.html)

- [CAPEC-645: Use of Captured Tickets (Pass The Ticket)](https://capec.mitre.org/data/definitions/645.html)

### [CAPEC-653: Use of Known Windows Credentials](https://capec.mitre.org/data/definitions/653.html)

- [CAPEC-561: Windows Admin Shares with Stolen Credentials](https://capec.mitre.org/data/definitions/561.html)

- [CAPEC-644: Use of Captured Hashes (Pass The Hash)](https://capec.mitre.org/data/definitions/644.html)

## Password Abuse

### [CAPEC-50: Password Recovery Exploitation](https://capec.mitre.org/data/definitions/50.html)

### [CAPEC-16: Dictionary Based Password Attack](https://capec.mitre.org/data/definitions/16.html)

### [CAPEC-49: Password Brute Forcing](https://capec.mitre.org/data/definitions/49.html)

- [CAPEC-565: Password Spraying](https://capec.mitre.org/data/definitions/565.html)

### [CAPEC-70 Try Common or Default Usernames and Passwords](https://capec.mitre.org/data/definitions/70.html)

### [CAPEC-55: Rainbow Table Password Cracking](https://capec.mitre.org/data/definitions/55.html)

## Encryption Abuse

### [CAPEC-112: Brute Force](https://capec.mitre.org/data/definitions/112.html)

### [CAPEC-20: Encryption Brute Forcing](https://capec.mitre.org/data/definitions/20.html)

## [CAPEC-549: Local Code Execution](https://capec.mitre.org/data/definitions/549.html)

### [CAPEC-542: Targeted Malware](https://capec.mitre.org/data/definitions/542.html)

- [CAPEC-550: Install New Service](https://capec.mitre.org/data/definitions/550.html)

- [CAPEC-551: Modify Existing Service](https://capec.mitre.org/data/definitions/551.html)

- [CAPEC-552: Install Rootkit](https://capec.mitre.org/data/definitions/552.html)

- [CAPEC-556: Replace File Extension Handlers](https://capec.mitre.org/data/definitions/556.html)

- [CAPEC-558: Replace Trusted Executable](https://capec.mitre.org/data/definitions/558.html)

- [CAPEC-564: Run Software at Login](https://capec.mitre.org/data/definitions/564.html)

- [CAPEC-579: Replace Winlogon Helper DLL](https://capec.mitre.org/data/definitions/579.html)

## [CAPEC-248: Command Injection](https://capec.mitre.org/data/definitions/248.html)

### [CAPEC-136 LDAP Injection](https://capec.mitre.org/data/definitions/136.html)

### [CAPEC-66 SQL Injection](https://capec.mitre.org/data/definitions/66.html)

- [CAPEC-7: Blind SQL Injection](https://capec.mitre.org/data/definitions/7.html)

- [CAPEC-109: Object Relational Mapping Injection](https://capec.mitre.org/data/definitions/109.html)

- [CAPEC-110: SQL Injection through SOAP Parameter Tampering](https://capec.mitre.org/data/definitions/110.html)

- [CAPEC-108: Command Line Execution through SQL Injection](https://capec.mitre.org/data/definitions/108.html)

- [CAPEC-470: Expanding Control over the Operating System from the Database](https://capec.mitre.org/data/definitions/470.html)

### [CAPEC-88 OS Command Injection](https://capec.mitre.org/data/definitions/88.html)

### [CAPEC-183 IMAP/SMTP Command Injection](https://capec.mitre.org/data/definitions/183.html)

### [CAPEC-250 XML Injection](https://capec.mitre.org/data/definitions/250.html)

- [CAPEC-83: XPath Injection](https://capec.mitre.org/data/definitions/83.html)

- [CAPEC-84: XQuery Injection](https://capec.mitre.org/data/definitions/84.html)

- [CAPEC-228: DTD Injection](https://capec.mitre.org/data/definitions/228.html)

### [CAPEC-676 NoSQL Injection](https://capec.mitre.org/data/definitions/676.html)

### [CAPEC-40 Manipulating Writeable Terminal Devices](https://capec.mitre.org/data/definitions/40.html)

### [CAPEC-137: Parameter Injection](https://capec.mitre.org/data/definitions/137.html)

- [CAPEC-6: Argument Injection](https://capec.mitre.org/data/definitions/6.html)

- [CAPEC-15: Command Delimiters](https://capec.mitre.org/data/definitions/15.html)

	- [CAPEC-460: HTTP Parameter Pollution (HPP)](https://capec.mitre.org/data/definitions/460.html)

- [CAPEC-134: Email Injection](https://capec.mitre.org/data/definitions/134.html)

- [CAPEC-135: Format String Injection](https://capec.mitre.org/data/definitions/135.html)

- [CAPEC-138: Reflection Injection](https://capec.mitre.org/data/definitions/138.html)

- [CAPEC-182: Flash Injection](https://capec.mitre.org/data/definitions/182.html)

	- [CAPEC-174: Flash Parameter Injection](https://capec.mitre.org/data/definitions/174.html)

	- [CAPEC-178: Cross-Site Flashing](https://capec.mitre.org/data/definitions/178.html)

### [CAPEC-175: Code Inclusion](https://capec.mitre.org/data/definitions/175.html)

- [CAPEC-251: Local Code Inclusion](https://capec.mitre.org/data/definitions/251.html)

	- [CAPEC-252: PHP Local File Inclusion](https://capec.mitre.org/data/definitions/252.html)

	- [CAPEC-640: Inclusion of Code in Existing Process](https://capec.mitre.org/data/definitions/640.html)

	- [CAPEC-660: Root/Jailbreak Detection Evasion via Hooking](https://capec.mitre.org/data/definitions/660.html)

- [CAPEC-253: Remote Code Inclusion](https://capec.mitre.org/data/definitions/253.html)

	- [CAPEC-101: Server Side Include (SSI) Injection](https://capec.mitre.org/data/definitions/101.html)

	- [CAPEC-193: PHP Remote File Inclusion](https://capec.mitre.org/data/definitions/193.html)

	- [CAPEC-500: WebView Injection](https://capec.mitre.org/data/definitions/500.html)

## [CAPEC-242: Code Injection](https://capec.mitre.org/data/definitions/242.html)

### [CAPEC-19: Embedding Scripts within Scripts](https://capec.mitre.org/data/definitions/19.html)

### [CAPEC-23: File Content Injection](https://capec.mitre.org/data/definitions/23.html)

- [CAPEC-44: Overflow Binary Resource File](https://capec.mitre.org/data/definitions/44.html)

### [CAPEC-41: Using Meta-Characters in E-mail Headers to Inject Malicious Payloads](https://capec.mitre.org/data/definitions/41.html)

### [CAPEC-63: Cross-site Scripting (XSS)](https://capec.mitre.org/data/definitions/63.html)

- [CAPEC-588: DOM-Based XSS](https://capec.mitre.org/data/definitions/588.html)

	- [CAPEC-18: XSS Through Non-Script Elements](https://capec.mitre.org/data/definitions/18.html)

	- [CAPEC-32: XSS Through HTTP Query String](https://capec.mitre.org/data/definitions/32.html)

	- [CAPEC-86: XSS Through HTTP Headers](https://capec.mitre.org/data/definitions/86.html)

	- [CAPEC-198: XSS Targeting Error Pages](https://capec.mitre.org/data/definitions/198.html)

	- [CAPEC-199: XSS Using Alternate Syntax](https://capec.mitre.org/data/definitions/199.html)

	- [CAPEC-243: XSS Targeting HTML Attributes](https://capec.mitre.org/data/definitions/243.html)

	- [CAPEC-244: XSS Targeting URI Placeholders](https://capec.mitre.org/data/definitions/244.html)

	- [CAPEC-245: XSS Using Doubled Characters](https://capec.mitre.org/data/definitions/245.html)

	- [CAPEC-247: XSS Using Invalid Characters](https://capec.mitre.org/data/definitions/247.html)

- [CAPEC-591: Reflected XSS](https://capec.mitre.org/data/definitions/591.html)

	- [CAPEC-18: XSS Through Non-Script Elements](https://capec.mitre.org/data/definitions/18.html)

	- [CAPEC-32: XSS Through HTTP Query String](https://capec.mitre.org/data/definitions/32.html)

	- [CAPEC-86: XSS Through HTTP Headers](https://capec.mitre.org/data/definitions/86.html)

	- [CAPEC-198: XSS Targeting Error Pages](https://capec.mitre.org/data/definitions/198.html)

	- [CAPEC-199: XSS Using Alternate Syntax](https://capec.mitre.org/data/definitions/199.html)

	- [CAPEC-243: XSS Targeting HTML Attributes](https://capec.mitre.org/data/definitions/243.html)

	- [CAPEC-244: XSS Targeting URI Placeholders](https://capec.mitre.org/data/definitions/244.html)

	- [CAPEC-245: XSS Using Doubled Characters](https://capec.mitre.org/data/definitions/245.html)

	- [CAPEC-247: XSS Using Invalid Characters](https://capec.mitre.org/data/definitions/247.html)

- [CAPEC-592: Stored XSS](https://capec.mitre.org/data/definitions/592.html)

	- [CAPEC-18: XSS Through Non-Script Elements](https://capec.mitre.org/data/definitions/18.html)

	- [CAPEC-32: XSS Through HTTP Query String](https://capec.mitre.org/data/definitions/32.html)

	- [CAPEC-86: XSS Through HTTP Headers](https://capec.mitre.org/data/definitions/86.html)

	- [CAPEC-198: XSS Targeting Error Pages](https://capec.mitre.org/data/definitions/198.html)

	- [CAPEC-199: XSS Using Alternate Syntax](https://capec.mitre.org/data/definitions/199.html)

	- [CAPEC-243: XSS Targeting HTML Attributes](https://capec.mitre.org/data/definitions/243.html)

	- [CAPEC-244: XSS Targeting URI Placeholders](https://capec.mitre.org/data/definitions/244.html)

	- [CAPEC-245: XSS Using Doubled Characters](https://capec.mitre.org/data/definitions/245.html)

	- [CAPEC-247: XSS Using Invalid Characters](https://capec.mitre.org/data/definitions/247.html)

	- [CAPEC-209: XSS Using MIME Type Mismatch](https://capec.mitre.org/data/definitions/209.html)

### [CAPEC-468: Generic Cross-Browser Cross-Domain Theft](https://capec.mitre.org/data/definitions/468.html)

## [CAPEC-240: Resource Injection](https://capec.mitre.org/data/definitions/240.html)

### [CAPEC-610: Cellular Data Injection](https://capec.mitre.org/data/definitions/610.html)

## [CAPEC-586: Object Injection](https://capec.mitre.org/data/definitions/586.html)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

