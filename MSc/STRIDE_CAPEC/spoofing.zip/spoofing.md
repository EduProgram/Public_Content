# Spoofing

## [ CAPEC-148: Content Spoofing](https://capec.mitre.org/data/definitions/148.html)

### [CAPEC-145: Checksum Spoofing](https://capec.mitre.org/data/definitions/145.html)

### [CAPEC-218: Spoofing of UDDI/ebXML Messages](https://capec.mitre.org/data/definitions/218.html)

### [ CAPEC-502: Intent Spoof](https://capec.mitre.org/data/definitions/502.html)

### [ CAPEC-627: Counterfeit GPS Signals](https://capec.mitre.org/data/definitions/627.html)

- [CAPEC-628: Carry-Off GPS Attack](https://capec.mitre.org/data/definitions/628.html)

## [CAPEC-151: Identity Spoofing](https://capec.mitre.org/data/definitions/151.html)

### [ CAPEC-194: Fake the Source of Data](https://capec.mitre.org/data/definitions/194.html)

- [ CAPEC-275: DNS Rebinding](https://capec.mitre.org/data/definitions/275.html)

- [CAPEC-543: Counterfeit Websites](https://capec.mitre.org/data/definitions/543.html)

- [CAPEC-544: Counterfeit Organizations](https://capec.mitre.org/data/definitions/544.html)

- [CAPEC-598: DNS Spoofing](https://capec.mitre.org/data/definitions/598.html)

- [CAPEC-633: Token Impersonation](https://capec.mitre.org/data/definitions/633.html)

### [CAPEC-195: Principal Spoof](https://capec.mitre.org/data/definitions/195.html)

- [CAPEC-587: Cross Frame Scripting (XFS)](https://capec.mitre.org/data/definitions/587.html)

- [CAPEC-599: Terrestrial Jamming](https://capec.mitre.org/data/definitions/599.html)

### [ CAPEC-473: Signature Spoof](https://capec.mitre.org/data/definitions/473.html)

- [CAPEC-459: Creating a Rogue Certification Authority Certificate](https://capec.mitre.org/data/definitions/459.html)

- [CAPEC-474: Signature Spoofing by Key Theft](https://capec.mitre.org/data/definitions/474.html)

- [CAPEC-475: Signature Spoofing by Improper Validation](https://capec.mitre.org/data/definitions/475.html)

- [CAPEC-476: Signature Spoofing by Misrepresentation](https://capec.mitre.org/data/definitions/476.html)

- [CAPEC-477: Signature Spoofing by Mixing Signed and Unsigned Content](https://capec.mitre.org/data/definitions/477.html)

- [CAPEC-479: Malicious Root Certificate](https://capec.mitre.org/data/definitions/479.html)

- [CAPEC-485: Signature Spoofing by Key Recreation](https://capec.mitre.org/data/definitions/485.html)

### [ CAPEC-89: Pharming](https://capec.mitre.org/data/definitions/89.html)

### [CAPEC-98: Phishing](https://capec.mitre.org/data/definitions/98.html)

- [CAPEC-163: Spear Phishing](https://capec.mitre.org/data/definitions/163.html)

- [CAPEC-164: Mobile Phishing](https://capec.mitre.org/data/definitions/164.html)

- [CAPEC-656: Voice Phishing](https://capec.mitre.org/data/definitions/656.html)

## [CAPEC-154: Resource Location Spoofing](https://capec.mitre.org/data/definitions/154.html)

### [CAPEC-159: Redirect Access to Libraries](https://capec.mitre.org/data/definitions/159.html)

- [CAPEC-132: Symlink Attack](https://capec.mitre.org/data/definitions/132.html)

- [CAPEC-38: Leveraging/Manipulating Configuration File Search Paths](https://capec.mitre.org/data/definitions/38.html)

- [CAPEC-471: Search Order Hijacking](https://capec.mitre.org/data/definitions/471.html)

- [CAPEC-641: DLL Side-Loading](https://capec.mitre.org/data/definitions/641.html)

### [CAPEC-141: Cache Poisoning](https://capec.mitre.org/data/definitions/141.html)

- [CAPEC-51: Poison Web Service Registry](https://capec.mitre.org/data/definitions/51.html)

- [CAPEC-142: DNS Cache Poisoning](https://capec.mitre.org/data/definitions/142.html)

### [CAPEC-616: Establish Rogue Location](https://capec.mitre.org/data/definitions/616.html)

- [CAPEC-505: Scheme Squatting](https://capec.mitre.org/data/definitions/505.html)

- [CAPEC-611: BitSquatting](https://capec.mitre.org/data/definitions/611.html)

- [CAPEC-615: Evil Twin Wi-Fi Attack](https://capec.mitre.org/data/definitions/615.html)

- [CAPEC-617: Cellular Rogue Base Station](https://capec.mitre.org/data/definitions/617.html)

- [CAPEC-630: TypoSquatting](https://capec.mitre.org/data/definitions/630.html)

- [CAPEC-631: SoundSquatting](https://capec.mitre.org/data/definitions/631.html)

- [CAPEC-632: Homograph Attack via Homoglyphs](https://capec.mitre.org/data/definitions/632.html)

- [CAPEC-667: Bluetooth Impersonation AttackS (BIAS)](https://capec.mitre.org/data/definitions/667.html)

## [CAPEC-173: Action Spoofing](https://capec.mitre.org/data/definitions/173.html)

### [CAPEC-103: Clickjacking](https://capec.mitre.org/data/definitions/103.html)

- [CAPEC-181: Flash File Overlay](https://capec.mitre.org/data/definitions/181.html)

- [CAPEC-222: iFrame Overlay](https://capec.mitre.org/data/definitions/222.html)

### [CAPEC-501: Android Activity Hijack](https://capec.mitre.org/data/definitions/501.html)

### [CAPEC-504: Task Impersonation](https://capec.mitre.org/data/definitions/504.html)

- [CAPEC-654: Credential Prompt Impersonation](https://capec.mitre.org/data/definitions/654.html)

### [CAPEC-506: Tapjacking](https://capec.mitre.org/data/definitions/506.html)

## [CAPEC-416: Manipulate Human Behavior](https://capec.mitre.org/data/definitions/416.html)

### [CAPEC-407: Pretexting](https://capec.mitre.org/data/definitions/407.html)

- [CAPEC-383: Harvesting Information via API Event Monitoring](https://capec.mitre.org/data/definitions/383.html)

- [CAPEC-412: Pretexting via Customer Service](https://capec.mitre.org/data/definitions/412.html)

- [CAPEC-413: Pretexting via Tech Support](https://capec.mitre.org/data/definitions/413.html)

- [CAPEC-414: Pretexting via Delivery Person](https://capec.mitre.org/data/definitions/414.html)

- [CAPEC-415: Pretexting via Phone](https://capec.mitre.org/data/definitions/415.html)

### [CAPEC-417: Influence Perception](https://capec.mitre.org/data/definitions/417.html)

- [CAPEC-418: Influence Perception of Reciprocation](https://capec.mitre.org/data/definitions/418.html)

- [CAPEC-420: Influence Perception of Scarcity](https://capec.mitre.org/data/definitions/420.html)

- [CAPEC-421: Influence Perception of Authority](https://capec.mitre.org/data/definitions/421.html)

- [CAPEC-422: Influence Perception of Commitment and Consistency](https://capec.mitre.org/data/definitions/422.html)

- [CAPEC-423: Influence Perception of Liking](https://capec.mitre.org/data/definitions/423.html)

- [CAPEC-424: Influence Perception of Consensus or Social Proof](https://capec.mitre.org/data/definitions/424.html)

### [CAPEC-425: Target Influence via Framing](https://capec.mitre.org/data/definitions/425.html)

### [CAPEC-426: Influence via Incentives](https://capec.mitre.org/data/definitions/426.html)

### [CAPEC-427: Influence via Psychological Principles](https://capec.mitre.org/data/definitions/427.html)

- [CAPEC-428: Influence via Modes of Thinking](https://capec.mitre.org/data/definitions/428.html)

- [CAPEC-429: Target Influence via Eye Cues](https://capec.mitre.org/data/definitions/429.html)

- [CAPEC-433: Target Influence via The Human Buffer Overflow](https://capec.mitre.org/data/definitions/433.html)

- [CAPEC-434: Target Influence via Interview and Interrogation](https://capec.mitre.org/data/definitions/434.html)

- [CAPEC-435: Target Influence via Instant Rapport](https://capec.mitre.org/data/definitions/435.html)

## [CAPEC-389: Content Spoofing Via Application API Manipulation](https://capec.mitre.org/data/definitions/389.html)

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

