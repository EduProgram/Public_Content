# Denial of Service

## [CAPEC-125: Flooding](https://capec.mitre.org/data/definitions/125.html)

### [CAPEC-482: TCP Flood](https://capec.mitre.org/data/definitions/482.html)

### [CAPEC-486: UDP Flood](https://capec.mitre.org/data/definitions/486.html)

### [CAPEC-487: ICMP Flood](https://capec.mitre.org/data/definitions/487.html)

### [CAPEC-488: HTTP Flood](https://capec.mitre.org/data/definitions/488.html)

### [CAPEC-489: SSL Flood](https://capec.mitre.org/data/definitions/489.html)

### [CAPEC-490: Amplification](https://capec.mitre.org/data/definitions/490.html)

### [CAPEC-528: XML Flood](https://capec.mitre.org/data/definitions/528.html)

- [CAPEC-147: XML Ping of the Death](https://capec.mitre.org/data/definitions/147.html)

### [CAPEC-666: BlueSmacking](https://capec.mitre.org/data/definitions/666.html)

## [CAPEC-130: Excessive Allocation](https://capec.mitre.org/data/definitions/130.html)

### [CAPEC-230: Serialized Data with Nested Payloads](https://capec.mitre.org/data/definitions/230.html)

- [CAPEC-197: Exponential Data Expansion](https://capec.mitre.org/data/definitions/197.html)

- [CAPEC-491: Quadratic Data Expansion](https://capec.mitre.org/data/definitions/491.html)

### [CAPEC-231: Oversized Serialized Data Payloads](https://capec.mitre.org/data/definitions/231.html)

- [CAPEC-201: Serialized Data External Linking](https://capec.mitre.org/data/definitions/201.html)

- [CAPEC-229: Serialized Data Parameter Blowup](https://capec.mitre.org/data/definitions/229.html)

### [CAPEC-492: Regular Expression Exponential Blowup](https://capec.mitre.org/data/definitions/492.html)

### [CAPEC-493: SOAP Array Blowup](https://capec.mitre.org/data/definitions/493.html)

### [CAPEC-494: TCP Fragmentation](https://capec.mitre.org/data/definitions/494.html)

### [CAPEC-495: UDP Fragmentation](https://capec.mitre.org/data/definitions/495.html)

### [CAPEC-496: ICMP Fragmentation](https://capec.mitre.org/data/definitions/496.html)

## [CAPEC-131: Resource Leak Exposure](https://capec.mitre.org/data/definitions/131.html)

## [CAPEC-227: Sustained Client Engagement](https://capec.mitre.org/data/definitions/227.html)

### [CAPEC-469: HTTP DoS](https://capec.mitre.org/data/definitions/469.html)

## [CAPEC-25: Forced Deadlock](https://capec.mitre.org/data/definitions/25.html)

## [CAPEC-607: Obstruction](https://capec.mitre.org/data/definitions/607.html)

### [CAPEC-547: Physical Destruction of Device or Component](https://capec.mitre.org/data/definitions/547.html)

### [CAPEC-582: Route Disabling](https://capec.mitre.org/data/definitions/582.html)

- [CAPEC-583: Disabling Network Hardware](https://capec.mitre.org/data/definitions/583.html)

- [CAPEC-584: BGP Route Disabling](https://capec.mitre.org/data/definitions/584.html)

- [CAPEC-585: DNS Domain Seizure](https://capec.mitre.org/data/definitions/585.html)

### [CAPEC-601: Jamming](https://capec.mitre.org/data/definitions/601.html)

- [CAPEC-559: Orbital Jamming](https://capec.mitre.org/data/definitions/559.html)

- [CAPEC-604: Wi-Fi Jamming](https://capec.mitre.org/data/definitions/604.html)

- [CAPEC-605: Cellular Jamming](https://capec.mitre.org/data/definitions/605.html)

### [CAPEC-603: Blockage](https://capec.mitre.org/data/definitions/603.html)

- [CAPEC-589: DNS Blocking](https://capec.mitre.org/data/definitions/589.html)

- [CAPEC-590: IP Address Blocking](https://capec.mitre.org/data/definitions/590.html)

- [CAPEC-96: Block Access to Libraries](https://capec.mitre.org/data/definitions/96.html)

## [CAPEC-2: Inducing Account Lockout](https://capec.mitre.org/data/definitions/2.html)

## [This work is licensed under a Creative Commons Attribution-NoDerivatives 4.0 International License. Brett Crawley](https://creativecommons.org/licenses/by-nd/4.0/)

## LICENSE
The MITRE Corporation (MITRE) hereby grants you a non-exclusive, royalty-free license to use Common Attack Pattern Enumeration and Classification (CAPEC™) for research, development, and commercial purposes. Any copy you make for such purposes is authorized provided that you reproduce MITRE’s copyright designation and this license in any such copy.

DISCLAIMERS
ALL DOCUMENTS AND THE INFORMATION CONTAINED THEREIN ARE PROVIDED ON AN "AS IS" BASIS AND THE CONTRIBUTOR, THE ORGANIZATION HE/SHE REPRESENTS OR IS SPONSORED BY (IF ANY), THE MITRE CORPORATION, ITS BOARD OF TRUSTEES, OFFICERS, AGENTS, AND EMPLOYEES, DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION THEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.

